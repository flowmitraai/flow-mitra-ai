Add mobile readiness to this app WITHOUT changing existing web/desktop behavior. Make these additive changes:

1. DARK MODE: In src/index.css, add a complete `.dark` selector with dark-mode equivalents for every CSS variable in :root. In src/routes/__root.jsx, wrap RootComponent's children with `<ThemeProvider attribute="class" defaultTheme="system" enableSystem>` from next-themes. Update the viewport meta to include `viewport-fit=cover`.

2. BOTTOM TABS: Create src/components/BottomTabBar.jsx — a `fixed bottom-0 inset-x-0 z-50` bar visible only on screens below lg breakpoint, with 5 tabs (Dashboard '/', Library '/library', My Workflows '/my-workflows', Agents '/agents', History '/history') using lucide icons. Each tab link highlights when active via useRouterState. Add `pb-20 lg:pb-0` to the main content padding in AppLayout.jsx so content isn't hidden behind the bar. The bar must include `pb-[env(safe-area-inset-bottom)]` padding.

3. SAFE AREAS: Add `pt-[env(safe-area-inset-top)]` to AppTopbar's header element. Add `pb-[env(safe-area-inset-bottom)]` to the bottom tab bar.

4. OVERSCROLL: In src/index.css base layer, add `overscroll-behavior: none;` to the `body` selector and a new `.main-scroll { overscroll-behavior: contain; }` utility. Apply `main-scroll` to the main element in AppLayout.jsx.

5. TOUCH TARGETS: In src/components/ui/button.jsx, add a mobile-first minimum size: change the default size variant from `h-9 px-4 py-2` to `h-11 px-4 py-2 sm:h-9` and icon size from `h-9 w-9` to `h-11 w-11 sm:h-9 sm:w-9`.

6. BACK BUTTON: In src/components/PageHeader.jsx, accept an optional `showBack` prop. When true, render a back button (ArrowLeft icon) before the title that calls `window.history.back()`. In child routes (library_.$workflowId.jsx, builder.jsx), pass `showBack` to PageHeader.

7. TEXT SELECTION: In src/index.css, add `button, a, nav, [role="button"] { user-select: none; -webkit-user-select: none; }` in the base layer.

8. ACCOUNT DELETION: In src/routes/_authed/settings.jsx, add a third card titled 'Danger Zone' with a 'Delete account' button that opens an AlertDialog confirming permanent deletion and calls a server function.

9. PULL-TO-REFRESH: Create src/components/PullToRefresh.jsx using framer-motion drag gesture. Wrap the main content area in AppLayout with it. On release, call queryClient.invalidateQueries() and router.invalidate().

10. PAGE TRANSITIONS: In src/routes/_authed.jsx, wrap the Outlet with framer-motion AnimatePresence mode='wait', using a motion.div keyed by useLocation().pathname with slide-in-from-right / slide-out-to-left animations (200ms).

11. OPTIMISTIC UPDATES: In src/routes/_authed/my-workflows.jsx and favorites.jsx, for toggleFavorite and delete actions, use onMutate to update local state immediately and onError to rollback.

Do NOT remove the desktop sidebar, change existing route logic, or alter server functions. All changes must be additive.