import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Play, Copy, RotateCcw, CheckCircle2, AlertCircle, Sparkles } from "lucide-react";
import { runWorkflow } from "@/lib/server-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StatusBadge from "@/components/StatusBadge";

const initialValues = (inputs) =>
  Object.fromEntries((inputs || []).map((field) => [field.key, field.default ?? (field.type === "select" ? field.options?.[0] ?? "" : "")]));

export default function WorkflowRunner({ workflow, onRan }) {
  const [values, setValues] = useState(() => initialValues(workflow.inputs));
  const [running, setRunning] = useState(false);
  const [execution, setExecution] = useState(null);
  const [error, setError] = useState(null);
  const run = useServerFn(runWorkflow);

  const set = (key, value) => setValues((prev) => ({ ...prev, [key]: value }));

  const handleRun = async () => {
    const missing = (workflow.inputs || []).filter((field) => field.required && !String(values[field.key] ?? "").trim());
    if (missing.length) {
      setError(`Please fill in: ${missing.map((m) => m.label).join(", ")}`);
      return;
    }
    setRunning(true);
    setError(null);
    setExecution(null);
    try {
      const { execution: result } = await run({ data: { workflowId: workflow.id, inputs: values } });
      setExecution(result);
      if (result.status === "successful") toast.success("Workflow completed successfully");
      else toast.error("Workflow failed — see details below");
      onRan?.(result);
    } catch (err) {
      const message = err?.data?.message || err?.message || "Could not start the workflow.";
      setError(message);
      toast.error(message);
    } finally {
      setRunning(false);
    }
  };

  const copyOutput = async () => {
    try {
      await navigator.clipboard.writeText(execution?.output ?? "");
      toast.success("Output copied");
    } catch {
      toast.error("Could not copy to clipboard");
    }
  };

  const reset = () => {
    setValues(initialValues(workflow.inputs));
    setExecution(null);
    setError(null);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card className="border-border shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="font-heading text-base">Configure &amp; run</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {(workflow.inputs || []).map((field) => (
            <div key={field.key} className="space-y-1.5">
              <Label htmlFor={`f-${field.key}`}>
                {field.label}
                {field.required && <span className="ml-1 text-destructive">*</span>}
              </Label>
              {field.type === "textarea" && (
                <Textarea
                  id={`f-${field.key}`}
                  value={values[field.key] ?? ""}
                  onChange={(e) => set(field.key, e.target.value)}
                  placeholder={field.placeholder}
                  rows={4}
                />
              )}
              {field.type === "select" && (
                <Select value={values[field.key] ?? ""} onValueChange={(v) => set(field.key, v)}>
                  <SelectTrigger id={`f-${field.key}`}>
                    <SelectValue placeholder="Choose…" />
                  </SelectTrigger>
                  <SelectContent>
                    {(field.options || []).map((opt) => (
                      <SelectItem key={opt} value={opt}>
                        {opt}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              {field.type === "number" && (
                <Input
                  id={`f-${field.key}`}
                  type="number"
                  value={values[field.key] ?? ""}
                  onChange={(e) => set(field.key, e.target.value)}
                  placeholder={field.placeholder}
                />
              )}
              {field.type === "text" && (
                <Input
                  id={`f-${field.key}`}
                  value={values[field.key] ?? ""}
                  onChange={(e) => set(field.key, e.target.value)}
                  placeholder={field.placeholder}
                />
              )}
              {field.help && <p className="text-xs text-muted-foreground">{field.help}</p>}
            </div>
          ))}

          <div className="flex flex-wrap gap-2 pt-1">
            <Button onClick={handleRun} disabled={running} className="gap-2">
              {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              {running ? "Running…" : "Run Workflow"}
            </Button>
            <Button variant="outline" onClick={reset} disabled={running} className="gap-2">
              <RotateCcw className="h-4 w-4" /> Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="font-heading text-base">Output</CardTitle>
          {execution && (
            <div className="flex items-center gap-2">
              <StatusBadge status={execution.status} />
              {execution.output && (
                <Button variant="ghost" size="sm" onClick={copyOutput} className="gap-1.5">
                  <Copy className="h-3.5 w-3.5" /> Copy
                </Button>
              )}
            </div>
          )}
        </CardHeader>
        <CardContent>
          {running && (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Running your workflow…</p>
            </div>
          )}

          {!running && error && (
            <div className="flex gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4">
              <AlertCircle className="h-5 w-5 shrink-0 text-destructive" />
              <div>
                <p className="text-sm font-semibold text-destructive">Could not run</p>
                <p className="mt-1 text-sm text-muted-foreground">{error}</p>
              </div>
            </div>
          )}

          {!running && !error && execution?.status === "failed" && (
            <div className="flex gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4">
              <AlertCircle className="h-5 w-5 shrink-0 text-destructive" />
              <div>
                <p className="text-sm font-semibold text-destructive">Execution failed</p>
                <p className="mt-1 text-sm text-muted-foreground">{execution.error}</p>
              </div>
            </div>
          )}

          {!running && execution?.status === "successful" && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium text-emerald-600">
                <CheckCircle2 className="h-4 w-4" /> Completed in {Math.round((execution.duration_ms || 0) / 100) / 10}s
              </div>
              <pre className="max-h-[520px] overflow-auto whitespace-pre-wrap rounded-xl bg-secondary/60 p-4 text-sm leading-relaxed text-foreground">
                {execution.output}
              </pre>
            </div>
          )}

          {!running && !error && !execution && (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary">
                <Sparkles className="h-6 w-6" />
              </span>
              <p className="text-sm text-muted-foreground">Fill in the fields and run to see real AI output here.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}