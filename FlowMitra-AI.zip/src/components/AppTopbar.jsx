import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search, Bell, Menu, LogOut, User, ChevronDown } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/lib/AuthContext";
import { listExecutions } from "@/lib/server-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const statusStyles = {
  successful: "bg-emerald-100 text-emerald-700",
  failed: "bg-red-100 text-red-700",
  running: "bg-blue-100 text-blue-700",
  queued: "bg-slate-100 text-slate-700",
  cancelled: "bg-amber-100 text-amber-700",
};

export default function AppTopbar({ onOpenSidebar }) {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [term, setTerm] = useState("");
  const fetchExecutions = useServerFn(listExecutions);

  const { data } = useQuery({
    queryKey: ["topbar-executions"],
    queryFn: () => fetchExecutions({ data: {} }),
    refetchInterval: 30000,
  });
  const recent = (data?.items ?? []).slice(0, 6);

  const submitSearch = (e) => {
    e.preventDefault();
    navigate({ to: "/library", search: term.trim() ? { search: term.trim() } : {} });
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-card/80 px-4 backdrop-blur sm:px-6">
      <Button variant="ghost" size="icon" className="lg:hidden" onClick={onOpenSidebar} aria-label="Open navigation">
        <Menu className="h-5 w-5" />
      </Button>

      <form onSubmit={submitSearch} className="relative hidden max-w-md flex-1 sm:block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          placeholder="Search workflows…"
          className="h-10 pl-9"
          aria-label="Search workflows"
        />
      </form>

      <div className="ml-auto flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
              <Bell className="h-5 w-5" />
              {recent.length > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-primary" />}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>Recent activity</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {recent.length === 0 ? (
              <p className="px-3 py-6 text-center text-sm text-muted-foreground">No activity yet.</p>
            ) : (
              recent.map((exec) => (
                <DropdownMenuItem key={exec.id} onSelect={() => navigate({ to: "/history" })} className="flex flex-col items-start gap-1">
                  <span className="w-full truncate text-sm font-medium">{exec.workflow_name}</span>
                  <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase", statusStyles[exec.status])}>
                    {exec.status}
                  </span>
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="gap-2 px-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
                {(user?.full_name || user?.email || "U").charAt(0).toUpperCase()}
              </span>
              <span className="hidden max-w-[140px] truncate text-sm font-medium sm:inline">
                {user?.full_name || user?.email}
              </span>
              <ChevronDown className="hidden h-4 w-4 text-muted-foreground sm:inline" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="truncate">{user?.email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => navigate({ to: "/settings" })}>
              <User className="mr-2 h-4 w-4" /> Profile settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => logout()}>
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}