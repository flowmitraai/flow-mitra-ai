import { LayoutDashboard, Library, FolderKanban, Workflow, Bot, History, Plug, Star, Settings, LifeBuoy } from "lucide-react";

export const NAV_ITEMS = [
  { label: "Dashboard", to: "/", icon: LayoutDashboard },
  { label: "Workflow Library", to: "/library", icon: Library },
  { label: "My Workflows", to: "/my-workflows", icon: FolderKanban },
  { label: "Workflow Builder", to: "/builder", icon: Workflow },
  { label: "AI Agents", to: "/agents", icon: Bot },
  { label: "Execution History", to: "/history", icon: History },
  { label: "Integrations", to: "/integrations", icon: Plug },
  { label: "Favorites", to: "/favorites", icon: Star },
  { label: "Settings", to: "/settings", icon: Settings },
  { label: "Help Center", to: "/help", icon: LifeBuoy },
];