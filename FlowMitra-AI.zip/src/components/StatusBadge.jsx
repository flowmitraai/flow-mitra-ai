import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const STYLES = {
  successful: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  failed: "bg-red-100 text-red-700 hover:bg-red-100",
  running: "bg-blue-100 text-blue-700 hover:bg-blue-100",
  queued: "bg-slate-100 text-slate-700 hover:bg-slate-100",
  cancelled: "bg-amber-100 text-amber-700 hover:bg-amber-100",
};

export default function StatusBadge({ status }) {
  return (
    <Badge variant="secondary" className={cn("border-0 font-semibold capitalize", STYLES[status] || STYLES.queued)}>
      {status}
    </Badge>
  );
}