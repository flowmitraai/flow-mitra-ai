import { Link, useRouterState } from "@tanstack/react-router";
import { Workflow as WorkflowIcon } from "lucide-react";
import { NAV_ITEMS } from "@/components/nav-items";
import { cn } from "@/lib/utils";

export default function AppSidebar({ onNavigate }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="flex h-full flex-col border-r border-sidebar-border bg-sidebar">
      <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-5">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <WorkflowIcon className="h-5 w-5" />
        </span>
        <div className="leading-tight">
          <p className="font-heading text-sm font-bold tracking-tight text-foreground">FlowMitra AI</p>
          <p className="text-[11px] text-muted-foreground">Less Busywork. More Building.</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {NAV_ITEMS.map((item) => {
          const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={onNavigate}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground",
              )}
            >
              <Icon className="h-[18px] w-[18px] shrink-0" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-sidebar-border p-4">
        <div className="rounded-xl bg-secondary p-3">
          <p className="text-xs font-semibold text-secondary-foreground">Need a hand?</p>
          <p className="mt-1 text-[11px] text-muted-foreground">Browse the Help Center for setup guides.</p>
          <Link to="/help" onClick={onNavigate} className="mt-2 inline-block text-[11px] font-semibold text-primary hover:underline">
            Open Help Center →
          </Link>
        </div>
      </div>
    </div>
  );
}