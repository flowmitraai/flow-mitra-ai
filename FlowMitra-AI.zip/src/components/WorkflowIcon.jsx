import {
  Lightbulb, FileText, PenLine, Repeat, Video, Youtube, Search, Mail, ShoppingBag, Megaphone,
  Instagram, Calendar, Image as ImageIcon, Target, Filter, ClipboardList, Briefcase, BarChart3,
  Send, UserPlus, NotebookPen, ListChecks, Receipt, BookOpen, MessageSquare, Table, Headphones,
  Star, Sparkles, Bot, Workflow,
} from "lucide-react";

const ICONS = {
  Lightbulb, FileText, PenLine, Repeat, Video, Youtube, Search, Mail, ShoppingBag, Megaphone,
  Instagram, Calendar, Image: ImageIcon, Target, Filter, ClipboardList, Briefcase, BarChart3,
  Send, UserPlus, NotebookPen, ListChecks, Receipt, BookOpen, MessageSquare, Table, Headphones,
  Star, Sparkles, Bot, Workflow,
};

export default function WorkflowIcon({ name, className }) {
  const Icon = ICONS[name] || Sparkles;
  return <Icon className={className} />;
}