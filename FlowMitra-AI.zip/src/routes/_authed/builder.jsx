import { useState } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Plus, Trash2, ArrowUp, ArrowDown, Save, Upload, Download, Play, Loader2, Workflow as WorkflowIcon, Sparkles } from "lucide-react";
import { createWorkflow, getWorkflow, testPrompt, updateWorkflow } from "@/lib/server-fns";
import { CATEGORIES } from "@/lib/workflow-catalog";
import PageHeader from "@/components/PageHeader";
import BuilderInputField from "@/components/BuilderInputField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authed/builder")({
  validateSearch: (s) => ({ workflowId: s.workflowId || undefined }),
  loaderDeps: ({ search }) => ({ workflowId: search.workflowId }),
  loader: async ({ deps }) => (deps.workflowId ? await getWorkflow({ data: { id: deps.workflowId } }) : null),
  head: () => ({ meta: [{ title: "Workflow Builder · FlowMitra AI" }] }),
  remountDeps: ({ search }) => search.workflowId ?? "new",
  component: BuilderPage,
});

const NODE_TYPES = ["trigger", "ai", "data", "logic", "action"];

const blank = () => ({
  name: "",
  description: "",
  category: CATEGORIES[0],
  folder: "",
  system_prompt: "",
  prompt_template: "",
  inputs: [{ key: "input_1", label: "Input", type: "textarea", required: true }],
  nodes: [
    { id: "trigger", type: "trigger", label: "Manual Trigger" },
    { id: "generate", type: "ai", label: "AI Generation" },
    { id: "output", type: "action", label: "Return Output" },
  ],
});

function BuilderPage() {
  const loaded = Route.useLoaderData();
  const navigate = useNavigate();
  const router = useRouter();
  const [form, setForm] = useState(() => {
    if (!loaded) return blank();
    return {
      name: loaded.name ?? "",
      description: loaded.description ?? "",
      category: loaded.category ?? CATEGORIES[0],
      folder: loaded.folder ?? "",
      system_prompt: loaded.system_prompt ?? "",
      prompt_template: loaded.prompt_template ?? "",
      inputs: loaded.inputs?.length ? loaded.inputs : blank().inputs,
      nodes: loaded.nodes?.length ? loaded.nodes : blank().nodes,
    };
  });
  const [busy, setBusy] = useState(false);
  const [testValues, setTestValues] = useState({});
  const [testOutput, setTestOutput] = useState("");
  const [testBusy, setTestBusy] = useState(false);

  const create = useServerFn(createWorkflow);
  const update = useServerFn(updateWorkflow);
  const runTest = useServerFn(testPrompt);

  const isOwnWorkflow = loaded && !loaded.is_library;

  const set = (patch) => setForm((prev) => ({ ...prev, ...patch }));

  const setInput = (index, patch) =>
    set({ inputs: form.inputs.map((field, i) => (i === index ? { ...field, ...patch } : field)) });
  const addInput = () => {
    let next = 1;
    while (form.inputs.some((field) => field.key === `input_${next}`)) next += 1;
    set({ inputs: [...form.inputs, { key: `input_${next}`, label: "New field", type: "text", required: false }] });
  };
  const removeInput = (index) => set({ inputs: form.inputs.filter((_, i) => i !== index) });

  const setNode = (index, patch) => set({ nodes: form.nodes.map((node, i) => (i === index ? { ...node, ...patch } : node)) });
  const addNode = () => set({ nodes: [...form.nodes, { id: `node_${Date.now()}`, type: "action", label: "New node" }] });
  const removeNode = (index) => set({ nodes: form.nodes.filter((_, i) => i !== index) });
  const moveNode = (index, dir) => {
    const target = index + dir;
    if (target < 0 || target >= form.nodes.length) return;
    const next = [...form.nodes];
    [next[index], next[target]] = [next[target], next[index]];
    set({ nodes: next });
  };

  const buildTestPrompt = () =>
    form.prompt_template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, key) => {
      const value = testValues[key];
      return value === undefined || value === "" ? "sample value" : value;
    });

  const runNodeTest = async () => {
    if (!form.prompt_template.trim()) return toast.error("Add a prompt template first");
    setTestBusy(true);
    setTestOutput("");
    try {
      const { output } = await runTest({ data: { prompt: buildTestPrompt(), system_prompt: form.system_prompt || undefined } });
      setTestOutput(output);
      toast.success("Test completed");
    } catch (err) {
      setTestOutput(`Error: ${err?.data?.message || err?.message || "Test failed"}`);
      toast.error("Test failed");
    } finally {
      setTestBusy(false);
    }
  };

  const save = async () => {
    if (!form.name.trim()) return toast.error("Please name your workflow");
    setBusy(true);
    try {
      if (isOwnWorkflow) {
        await update({ data: { id: loaded.id, ...form } });
        toast.success("Workflow saved");
      } else {
        await create({ data: form });
        toast.success(loaded ? "Saved as a new workflow in My Workflows" : "Workflow created");
      }
      await router.invalidate();
      await navigate({ to: "/my-workflows" });
    } catch (err) {
      toast.error(err?.data?.message || err?.message || "Could not save the workflow");
    } finally {
      setBusy(false);
    }
  };

  const onExport = () => {
    const blob = new Blob([JSON.stringify(form, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(form.name || "workflow").replace(/\s+/g, "-").toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const onImport = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        set({
          name: parsed.name ?? "",
          description: parsed.description ?? "",
          category: parsed.category ?? CATEGORIES[0],
          folder: parsed.folder ?? "",
          system_prompt: parsed.system_prompt ?? "",
          prompt_template: parsed.prompt_template ?? "",
          inputs: Array.isArray(parsed.inputs) && parsed.inputs.length ? parsed.inputs : blank().inputs,
          nodes: Array.isArray(parsed.nodes) && parsed.nodes.length ? parsed.nodes : blank().nodes,
        });
        toast.success("Workflow imported");
      } catch {
        toast.error("That file is not valid workflow JSON");
      }
    };
    reader.readAsText(file);
    event.target.value = "";
  };

  return (
    <div>
      <PageHeader
        title="Workflow Builder"
        description={isOwnWorkflow ? "Editing your saved workflow." : loaded ? "This library workflow will be saved as your own copy." : "Design a new workflow from scratch."}
        actions={
          <>
            <label>
              <input type="file" accept="application/json" className="hidden" onChange={onImport} />
              <Button asChild variant="outline" className="gap-2">
                <span>
                  <Upload className="h-4 w-4" /> Import JSON
                </span>
              </Button>
            </label>
            <Button variant="outline" onClick={onExport} className="gap-2">
              <Download className="h-4 w-4" /> Export JSON
            </Button>
            <Button onClick={save} disabled={busy} className="gap-2">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save workflow
            </Button>
          </>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-heading text-base">Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="b-name">Name</Label>
                <Input id="b-name" value={form.name} onChange={(e) => set({ name: e.target.value })} placeholder="e.g. Weekly report generator" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="b-desc">Description</Label>
                <Textarea id="b-desc" rows={2} value={form.description} onChange={(e) => set({ description: e.target.value })} />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => set({ category: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="b-folder">Folder</Label>
                  <Input id="b-folder" value={form.folder} onChange={(e) => set({ folder: e.target.value })} placeholder="Optional" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="font-heading text-base">Input fields</CardTitle>
              <Button size="sm" variant="outline" onClick={addInput} className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Add field
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {form.inputs.map((field, index) => (
                <BuilderInputField key={index} field={field} onChange={(patch) => setInput(index, patch)} onRemove={() => removeInput(index)} />
              ))}
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="font-heading text-base">Nodes</CardTitle>
              <Button size="sm" variant="outline" onClick={addNode} className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Add node
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {form.nodes.map((node, index) => (
                <div key={node.id || index} className="grid gap-2 rounded-xl border border-border p-3 sm:grid-cols-[1fr_150px_auto]">
                  <Input value={node.label} onChange={(e) => setNode(index, { label: e.target.value })} placeholder="Node label" />
                  <Select value={node.type} onValueChange={(v) => setNode(index, { type: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {NODE_TYPES.map((t) => (
                        <SelectItem key={t} value={t} className="capitalize">
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => moveNode(index, -1)} aria-label="Move up">
                      <ArrowUp className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => moveNode(index, 1)} aria-label="Move down">
                      <ArrowDown className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => removeNode(index)} aria-label="Remove node">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-heading text-base">Prompt</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="b-sys">System prompt</Label>
                <Textarea id="b-sys" rows={3} value={form.system_prompt} onChange={(e) => set({ system_prompt: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="b-prompt">Prompt template</Label>
                <Textarea
                  id="b-prompt"
                  rows={6}
                  value={form.prompt_template}
                  onChange={(e) => set({ prompt_template: e.target.value })}
                  placeholder="Use {{field_key}} to insert input values."
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 font-heading text-base">
                <Sparkles className="h-4 w-4 text-primary" /> Test the prompt
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {form.inputs.map((field) => (
                <div key={field.key} className="space-y-1">
                  <Label className="text-xs">{field.label}</Label>
                  <Input
                    value={testValues[field.key] ?? ""}
                    onChange={(e) => setTestValues((prev) => ({ ...prev, [field.key]: e.target.value }))}
                    placeholder="Sample value"
                  />
                </div>
              ))}
              <Button onClick={runNodeTest} disabled={testBusy} variant="outline" className="w-full gap-2">
                {testBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />} Run test
              </Button>
              {testOutput && (
                <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded-xl bg-secondary/60 p-3 text-xs text-foreground">{testOutput}</pre>
              )}
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <WorkflowIcon className="h-3.5 w-3.5" /> Runs a real AI call on your template.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}