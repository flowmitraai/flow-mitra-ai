import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Library, FolderKanban, CheckCircle2, XCircle, Rocket, Plus, Upload, LayoutTemplate, History, Sparkles, Plug } from "lucide-react";
import { dashboardData, listFavorites } from "@/lib/server-fns";
import { useAuth } from "@/lib/AuthContext";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import EmptyState from "@/components/EmptyState";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authed/")({
  loader: () => dashboardData(),
  head: () => ({ meta: [{ title: "Dashboard · FlowMitra AI" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const { stats, recentExecutions, favorites, recentWorkflows } = Route.useLoaderData();
  const { user } = useAuth();
  const firstName = (user?.full_name || user?.email || "there").split(" ")[0];

  const quickLinks = [
    { label: "Explore Workflows", to: "/library", icon: Library },
    { label: "Create Workflow", to: "/builder", icon: Plus },
    { label: "Import Workflow", to: "/builder", icon: Upload },
    { label: "Browse Templates", to: "/library", icon: LayoutTemplate },
    { label: "View History", to: "/history", icon: History },
  ];

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${firstName}`}
        description="Less Busywork. More Building. Here is what is happening across your automations."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Available workflows" value={stats.library} icon={Library} tone="primary" />
        <StatCard label="My saved workflows" value={stats.mine} icon={FolderKanban} tone="neutral" />
        <StatCard label="Successful executions" value={stats.successful} icon={CheckCircle2} tone="success" />
        <StatCard label="Failed executions" value={stats.failed} icon={XCircle} tone="danger" />
      </div>

      <Card className="mt-6 border-border shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="font-heading text-base">Quick start</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {quickLinks.map((link) => (
            <Button key={link.label} asChild variant="outline" className="gap-2">
              <Link to={link.to}>
                <link.icon className="h-4 w-4" /> {link.label}
              </Link>
            </Button>
          ))}
        </CardContent>
      </Card>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="border-border shadow-sm lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="font-heading text-base">Recent activity</CardTitle>
            <Button asChild variant="ghost" size="sm">
              <Link to="/history">View all</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {recentExecutions.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No executions yet. Run a workflow to see activity here.
              </p>
            ) : (
              <ul className="divide-y divide-border">
                {recentExecutions.map((exec) => (
                  <li key={exec.id} className="flex items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-foreground">{exec.workflow_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(exec.created_date).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
                      </p>
                    </div>
                    <StatusBadge status={exec.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-heading text-base">Integration status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-sm text-foreground">
                  <Sparkles className="h-4 w-4 text-primary" /> Base44 AI
                </span>
                <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">Connected</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Plug className="h-4 w-4" /> Email / Sheets / HTTP
                </span>
                <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-semibold text-slate-600">Needs setup</span>
              </div>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to="/integrations">Manage integrations</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-heading text-base">Favorites</CardTitle>
            </CardHeader>
            <CardContent>
              {favorites.length === 0 ? (
                <p className="py-4 text-center text-sm text-muted-foreground">No favorites yet.</p>
              ) : (
                <ul className="space-y-2">
                  {favorites.map((fav) => (
                    <li key={fav.id}>
                      <Link
                        to="/library/$workflowId"
                        params={{ workflowId: fav.workflow_id }}
                        className="block truncate text-sm text-foreground hover:text-primary"
                      >
                        {fav.workflow_name || "Workflow"}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {recentWorkflows.length > 0 && (
        <Card className="mt-6 border-border shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="font-heading text-base">Recently used</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {recentWorkflows.map((w) => (
              <Link
                key={w.id}
                to="/my-workflows"
                className="rounded-xl border border-border bg-card p-4 text-sm font-medium text-foreground shadow-sm transition-colors hover:border-primary/40 hover:text-primary"
              >
                {w.name}
              </Link>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}