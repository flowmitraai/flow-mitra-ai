import { useEffect, useState } from "react";
import { createFileRoute, notFound, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Star, Copy, Download, Wrench, KeyRound, ListChecks, Target, Clock, AlertCircle } from "lucide-react";
import { duplicateWorkflow, getWorkflow, listExecutions, listFavorites, toggleFavorite } from "@/lib/server-fns";
import PageHeader from "@/components/PageHeader";
import WorkflowRunner from "@/components/WorkflowRunner";
import WorkflowNodeGraph from "@/components/WorkflowNodeGraph";
import WorkflowIcon from "@/components/WorkflowIcon";
import StatusBadge from "@/components/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/library_/$workflowId")({
  loader: async ({ params }) => {
    const workflow = await getWorkflow({ data: { id: params.workflowId } });
    if (!workflow) throw notFound();
    const executions = await listExecutions({ data: { workflowId: params.workflowId } });
    return { workflow, executions: executions.items };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.workflow?.name ?? "Workflow"} · FlowMitra AI` }] }),
  component: WorkflowDetailPage,
});

function WorkflowDetailPage() {
  const { workflow, executions } = Route.useLoaderData();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [history, setHistory] = useState(executions);
  useEffect(() => setHistory(executions), [workflow.id, executions]);
  const fetchFavorites = useServerFn(listFavorites);
  const toggleFav = useServerFn(toggleFavorite);
  const duplicate = useServerFn(duplicateWorkflow);
  const { data: favorites } = useQuery({ queryKey: ["favorites"], queryFn: () => fetchFavorites() });
  const isFavorite = (favorites?.items ?? []).some((f) => f.workflow_id === workflow.id);

  const onToggleFavorite = async () => {
    await toggleFav({ data: { workflowId: workflow.id, workflowName: workflow.name } });
    await queryClient.invalidateQueries({ queryKey: ["favorites"] });
  };
  const onDuplicate = async () => {
    await duplicate({ data: { id: workflow.id } });
    toast.success("Added a copy to My Workflows");
    await router.invalidate();
    await router.navigate({ to: "/my-workflows" });
  };
  const onExport = () => {
    const blob = new Blob([JSON.stringify(workflow, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${workflow.slug || workflow.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <PageHeader title={workflow.name} description={workflow.description} actions={
        <>
          <Button variant="outline" onClick={onToggleFavorite} className="gap-2">
            <Star className={cn("h-4 w-4", isFavorite && "fill-amber-400 text-amber-400")} />
            {isFavorite ? "Favorited" : "Favorite"}
          </Button>
          <Button variant="outline" onClick={onExport} className="gap-2"><Download className="h-4 w-4" /> Export</Button>
          <Button onClick={onDuplicate} className="gap-2"><Copy className="h-4 w-4" /> Add to My Workflows</Button>
        </>
      } />
      <div className="mb-6 flex flex-wrap items-center gap-2">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-primary"><WorkflowIcon name={workflow.icon} className="h-5 w-5" /></span>
        <Badge variant="secondary" className="border-0 bg-secondary font-medium text-secondary-foreground">{workflow.category}</Badge>
        <Badge variant="secondary" className="border-0 capitalize">{workflow.difficulty}</Badge>
      </div>
      <Card className="mb-6 border-border shadow-sm">
        <CardHeader className="pb-4"><CardTitle className="font-heading text-base">Workflow diagram</CardTitle></CardHeader>
        <CardContent><WorkflowNodeGraph nodes={workflow.nodes} /></CardContent>
      </Card>
      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Card className="border-border shadow-sm">
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 font-heading text-sm"><Wrench className="h-4 w-4 text-primary" /> Required tools</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            {(workflow.required_integrations || []).length === 0 ? <p>None — runs entirely on the built-in AI engine.</p> : (workflow.required_integrations || []).map((tool) => <p key={tool} className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> {tool}</p>)}
          </CardContent>
        </Card>
        <Card className="border-border shadow-sm">
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 font-heading text-sm"><KeyRound className="h-4 w-4 text-primary" /> Credentials</CardTitle></CardHeader>
          <CardContent className="text-sm text-muted-foreground">This workflow runs on the built-in Base44 AI engine, so no API keys are required. Credentials are never exposed to the browser.</CardContent>
        </Card>
        <Card className="border-border shadow-sm">
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 font-heading text-sm"><Target className="h-4 w-4 text-primary" /> Expected output</CardTitle></CardHeader>
          <CardContent className="text-sm text-muted-foreground">{workflow.expected_output}</CardContent>
        </Card>
      </div>
      <div className="mb-6 rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="flex items-center gap-2 font-heading text-sm font-semibold text-foreground"><ListChecks className="h-4 w-4 text-primary" /> Setup instructions</h2>
        <p className="mt-2 text-sm text-muted-foreground">{workflow.setup_instructions}</p>
      </div>
      <h2 className="mb-3 font-heading text-lg font-semibold text-foreground">Run this workflow</h2>
      <WorkflowRunner key={workflow.id} workflow={workflow} onRan={(result) => {
        setHistory((prev) => [result, ...prev]);
        queryClient.invalidateQueries({ queryKey: ["recent-executions"] });
      }} />
      <Card className="mt-8 border-border shadow-sm">
        <CardHeader className="pb-4"><CardTitle className="flex items-center gap-2 font-heading text-base"><Clock className="h-4 w-4 text-primary" /> Execution history</CardTitle></CardHeader>
        <CardContent>
          {history.length === 0 ? <p className="py-8 text-center text-sm text-muted-foreground">No executions yet for this workflow.</p> : (
            <ul className="divide-y divide-border">{history.map((exec) => (
              <li key={exec.id} className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground">{new Date(exec.created_date).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" })}</p>
                  {exec.error && <p className="mt-1 flex items-start gap-1.5 text-xs text-destructive"><AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {exec.error}</p>}
                </div>
                <div className="flex items-center gap-3"><span className="text-xs text-muted-foreground">{Math.round((exec.duration_ms || 0) / 100) / 10}s</span><StatusBadge status={exec.status} /></div>
              </li>
            ))}</ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}