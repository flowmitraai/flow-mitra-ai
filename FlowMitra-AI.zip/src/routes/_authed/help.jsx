import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search, LifeBuoy } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authed/help")({
  head: () => ({ meta: [{ title: "Help Center · FlowMitra AI" }] }),
  component: HelpPage,
});

const ARTICLES = [
  {
    q: "How do I run a workflow?",
    a: "Open any workflow from the library or My Workflows, fill in the required fields on the left, then click Run Workflow. The output appears on the right. A run only shows as successful when the backend confirms it — failures show the real error message.",
  },
  {
    q: "How do I import a workflow?",
    a: "Go to Workflow Builder and use Import JSON to load a workflow file you exported earlier. The builder validates the structure, then you can review the nodes and save it to My Workflows.",
  },
  {
    q: "How do I export a workflow?",
    a: "Open a workflow and click Export, or use the export button on any card in My Workflows. You get a JSON file containing the workflow's inputs, prompt template and node graph.",
  },
  {
    q: "Which credentials do I need?",
    a: "All starter workflows run on the built-in Base44 AI engine, so no API keys are required. Integrations such as email, spreadsheets and generic HTTP APIs need their own credentials, stored as server-side secrets — never in browser code. The Integrations page shows the real status of each provider.",
  },
  {
    q: "How do I configure credentials?",
    a: "Open Integrations to see what each provider requires. Anything labelled 'Needs configuration' cannot be used yet — the page tells you exactly what to supply. Providers are never shown as connected until they truly are.",
  },
  {
    q: "Troubleshooting a failed execution",
    a: "Open Execution History and find the run. Failed runs show the exact error message and the node that failed. Common causes are missing required inputs or hitting the execution limit (10 runs per minute). Fix the input and run again.",
  },
  {
    q: "How do I use AI agents?",
    a: "Open AI Agents, create an agent with its own system instructions and model, then click Test agent to send it a message and see a real response. Agents are saved to your account and are private to you.",
  },
  {
    q: "How do folders and favorites work?",
    a: "In My Workflows, give a workflow a folder name to group it, and use the Folder filter to narrow the list. Star any workflow to pin it to Favorites for quick access.",
  },
];

function HelpPage() {
  const [term, setTerm] = useState("");
  const filtered = useMemo(() => {
    const t = term.trim().toLowerCase();
    if (!t) return ARTICLES;
    return ARTICLES.filter((a) => a.q.toLowerCase().includes(t) || a.a.toLowerCase().includes(t));
  }, [term]);

  return (
    <div>
      <PageHeader title="Help Center" description="Guides for running workflows, credentials, exports, agents and troubleshooting." />

      <div className="relative mb-6 max-w-xl">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search the documentation…" className="pl-9" />
      </div>

      {filtered.length === 0 ? (
        <Card className="border-border shadow-sm">
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <LifeBuoy className="h-6 w-6 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">No articles match “{term}”. Try a different keyword.</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border shadow-sm">
          <CardContent className="p-2 sm:p-4">
            <Accordion type="single" collapsible className="w-full">
              {filtered.map((article, index) => (
                <AccordionItem key={article.q} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-sm font-semibold">{article.q}</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">{article.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      )}
    </div>
  );
}