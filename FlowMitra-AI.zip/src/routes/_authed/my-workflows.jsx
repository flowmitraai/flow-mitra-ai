import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Plus, Search, FolderKanban, Star, Copy, Download, Trash2, Pencil, Loader2, Play } from "lucide-react";
import { createWorkflow, deleteWorkflow, duplicateWorkflow, listMyFolders, listMyWorkflows, updateWorkflow, listFavorites, toggleFavorite } from "@/lib/server-fns";
import { CATEGORIES } from "@/lib/workflow-catalog";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/my-workflows")({
  validateSearch: (s) => ({ search: s.search || undefined, folder: s.folder || undefined }),
  loaderDeps: ({ search }) => search,
  loader: ({ deps }) => Promise.all([listMyWorkflows({ data: deps }), listMyFolders()]),
  head: () => ({ meta: [{ title: "My Workflows · FlowMitra AI" }] }),
  component: MyWorkflowsPage,
});

const emptyForm = { name: "", description: "", category: CATEGORIES[0], folder: "", prompt_template: "" };

function MyWorkflowsPage() {
  const [{ items }, folders] = Route.useLoaderData();
  const search = Route.useSearch();
  const navigate = useNavigate();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [term, setTerm] = useState(search.search ?? "");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState(null);

  const create = useServerFn(createWorkflow);
  const update = useServerFn(updateWorkflow);
  const remove = useServerFn(deleteWorkflow);
  const duplicate = useServerFn(duplicateWorkflow);
  const fetchFavorites = useServerFn(listFavorites);
  const toggleFav = useServerFn(toggleFavorite);
  const { data: favorites } = useQuery({ queryKey: ["favorites"], queryFn: () => fetchFavorites() });
  const favoriteIds = new Set((favorites?.items ?? []).map((favorite) => favorite.workflow_id));

  useEffect(() => setTerm(search.search ?? ""), [search.search]);

  const refresh = async () => {
    await queryClient.invalidateQueries();
    await router.invalidate();
  };

  useEffect(() => {
    const current = search.search ?? "";
    if (term === current) return;
    const id = setTimeout(() => navigate({ to: "/my-workflows", search: (prev) => ({ ...prev, search: term.trim() || undefined }) }), 350);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [term]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setDialogOpen(true);
  };
  const openEdit = (workflow) => {
    setEditing(workflow);
    setForm({
      name: workflow.name,
      description: workflow.description ?? "",
      category: workflow.category ?? CATEGORIES[0],
      folder: workflow.folder ?? "",
      prompt_template: workflow.prompt_template ?? "",
    });
    setDialogOpen(true);
  };

  const save = async () => {
    if (!form.name.trim()) {
      toast.error("Please enter a name");
      return;
    }
    setBusy(true);
    try {
      if (editing) {
        await update({ data: { id: editing.id, ...form } });
        toast.success("Workflow updated");
      } else {
        await create({ data: form });
        toast.success("Workflow created");
      }
      setDialogOpen(false);
      await refresh();
    } catch (err) {
      toast.error(err?.message || "Could not save the workflow");
    } finally {
      setBusy(false);
    }
  };

  const onDuplicate = async (workflow) => {
    await duplicate({ data: { id: workflow.id } });
    toast.success("Workflow duplicated");
    await refresh();
  };

  const onDelete = async () => {
    await remove({ data: { id: pendingDelete.id } });
    toast.success("Workflow deleted");
    setPendingDelete(null);
    await refresh();
  };

  const onExport = (workflow) => {
    const blob = new Blob([JSON.stringify(workflow, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${workflow.slug || workflow.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <PageHeader
        title="My Workflows"
        description="Your private workspace. Create, edit, organize and run your own workflows."
        actions={
          <Button onClick={openCreate} className="gap-2">
            <Plus className="h-4 w-4" /> New workflow
          </Button>
        }
      />

      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="my-search">Search</Label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input id="my-search" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search my workflows…" className="pl-9" />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Folder</Label>
          <Select
            value={search.folder ?? "all"}
            onValueChange={(v) => navigate({ to: "/my-workflows", search: (prev) => ({ ...prev, folder: v === "all" ? undefined : v }) })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All folders</SelectItem>
              {folders.map((f) => (
                <SelectItem key={f} value={f}>
                  {f}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="No workflows yet"
          description="Create your own workflow, or duplicate one from the library to get started."
          action={
            <div className="flex gap-2">
              <Button onClick={openCreate} className="gap-2">
                <Plus className="h-4 w-4" /> New workflow
              </Button>
              <Button asChild variant="outline">
                <Link to="/library">Browse library</Link>
              </Button>
            </div>
          }
        />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((workflow) => (
            <Card key={workflow.id} data-workflow-id={workflow.id} className="flex h-full flex-col border-border shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="font-heading text-base leading-snug">{workflow.name}</CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0 text-muted-foreground hover:text-amber-500"
                    aria-label={favoriteIds.has(workflow.id) ? "Remove from favorites" : "Add to favorites"}
                    onClick={async () => {
                      await toggleFav({ data: { workflowId: workflow.id, workflowName: workflow.name } });
                      await queryClient.invalidateQueries({ queryKey: ["favorites"] });
                    }}
                  >
                    <Star className={cn("h-4 w-4", favoriteIds.has(workflow.id) && "fill-amber-400 text-amber-400")} />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex flex-1 flex-col">
                <p className="line-clamp-3 flex-1 text-sm text-muted-foreground">{workflow.description || "No description."}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge variant="secondary" className="border-0 bg-secondary text-secondary-foreground">
                    {workflow.category || "Uncategorized"}
                  </Badge>
                  {workflow.folder && <Badge variant="outline">{workflow.folder}</Badge>}
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button asChild size="sm" className="gap-1.5">
                    <Link to="/library/$workflowId" params={{ workflowId: workflow.id }}>
                      <Play className="h-3.5 w-3.5" /> Run
                    </Link>
                  </Button>
                  <Button asChild size="sm" variant="outline" className="gap-1.5">
                    <Link to="/builder" search={{ workflowId: workflow.id }}>
                      <Pencil className="h-3.5 w-3.5" /> Edit
                    </Link>
                  </Button>
                  <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => openEdit(workflow)}>
                    Rename
                  </Button>
                  <Button size="sm" variant="ghost" className="gap-1.5" aria-label="Duplicate workflow" onClick={() => onDuplicate(workflow)}>
                    <Copy className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" className="gap-1.5" aria-label="Export workflow" onClick={() => onExport(workflow)}>
                    <Download className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" className="gap-1.5 text-destructive hover:text-destructive" aria-label="Delete workflow" onClick={() => setPendingDelete(workflow)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-heading">{editing ? "Edit workflow" : "New workflow"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="wf-name">Name</Label>
              <Input id="wf-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Weekly client update" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="wf-desc">Description</Label>
              <Textarea id="wf-desc" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="wf-folder">Folder</Label>
                <Input id="wf-folder" value={form.folder} onChange={(e) => setForm({ ...form, folder: e.target.value })} placeholder="Optional" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="wf-prompt">Prompt template</Label>
              <Textarea
                id="wf-prompt"
                value={form.prompt_template}
                onChange={(e) => setForm({ ...form, prompt_template: e.target.value })}
                rows={4}
                placeholder="Use {{field_key}} to insert input values."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={save} disabled={busy} className="gap-2">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!pendingDelete} onOpenChange={(open) => !open && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this workflow?</AlertDialogTitle>
            <AlertDialogDescription>
              “{pendingDelete?.name}” and its configuration will be permanently removed. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}