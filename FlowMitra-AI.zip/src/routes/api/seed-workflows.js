const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute } from "@tanstack/react-router";
import { requireUserRoute } from "@/lib/auth-middleware";
import { LIBRARY_WORKFLOWS } from "@/lib/workflow-catalog";

// Seeds / restores the starter workflow library. Idempotent: records are
// matched by slug, so calling it again updates instead of duplicating.
export const Route = createFileRoute("/api/seed-workflows")({
  server: {
    middleware: [requireUserRoute],
    handlers: {
      POST: async ({ context }) => {
        const base44 = context.getBase44().asServiceRole;
        const records = LIBRARY_WORKFLOWS.map((w) => ({
          ...w,
          is_library: true,
          is_favorite: false,
          usage_count: 0,
        }));
        const result = await db.entities.Workflow.upsert(records, { key: "slug" });
        return Response.json({ created: result.created, updated: result.updated, total: records.length });
      },
    },
  },
});